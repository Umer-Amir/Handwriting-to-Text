import pytesseract
from PIL import Image

def tesseract_ocr(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img, config='--psm 10')  # For single characters
    return text.strip()

print(tesseract_ocr('char_1.png'))
