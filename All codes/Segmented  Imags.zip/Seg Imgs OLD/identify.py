from paddleocr import PaddleOCR

ocr = PaddleOCR(lang='en')  # need to run only once to download and load model into memory
image_path = "D:\MATLAB\bin\win64\AAA Images\All codes\Seg Imgs\char_1.png"
result = ocr.ocr("char_1.png", cls=True)
if result and len(result[0]) > 0:
    for res in result[0]:
        print(res[1][0])  # Extracted text
else:
    print("No text detected.")